import React from 'react'
import { Switch, Redirect, Route} from 'react-router-dom'

const RouteView = (props) => {
  console.log(props, 'props----index-router')
  return (
    <Switch>
      {
        props.routes.map((item, index) => {
         return <Route key={index} path={item.path} render={props => {
              return <item.component {...props} routes={item.children} />
          }}></Route>
        })
      }
      { props.match ?  <Redirect to={props.redirect} /> : <Redirect  to="/home"/> }
    </Switch>
  )
}

export default RouteView;






