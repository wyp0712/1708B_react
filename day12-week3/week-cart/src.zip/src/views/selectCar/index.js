import React, { Component } from 'react'
import RouterView from '../../router/index'

export default class componentName extends Component {
  render() {
    return (
      <div>
        selectcar
        <RouterView {...this.props} redirect='/selectcar/tab1' routes={this.props.routes}></RouterView>
      </div>
    )
  }
}
