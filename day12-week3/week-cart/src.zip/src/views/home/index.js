import React from 'react'
import { connect } from 'react-redux'

// react-redux  是redux的一个中间件 解决的是react和redux连接的问题
const Home = (props) => {
   const {inputValue,list,inputChange, handleBtnEvent, handleDeleteItem } = props
  return (
    <div>
      <input value={inputValue} 
        onChange={ inputChange }
        />
        <button onClick={ handleBtnEvent}>提交</button>
        {
          list.map((item, index) => {
            return <li onClick={() => handleDeleteItem(index)} key={index}>
              {item}
            </li>
          })
        }
    </div>
  )
}

// 属性 获取
const mapStateToProps = (state) => {
  return {
    inputValue: state.inputValue,
    list: state.list
  }
}

// action 提交
const mapDispatchToProps = (dispatch) => {
  return {
    inputChange(e) {
      const target = e.target
      const action = {
        type: 'input_change',
        value: target.value
      }
      dispatch(action)
    },
    handleBtnEvent() {
      const action = {
        type: 'add_input_value',
      }
      dispatch(action)
    },
    handleDeleteItem(index) {
      const action = {
        type: 'remove_input_value',
        index
      }
      dispatch(action)
    }
  }
}

// connect(mapStateToProps,mapDispatchToProps)(组件) 

export default connect(mapStateToProps, mapDispatchToProps)(Home)
