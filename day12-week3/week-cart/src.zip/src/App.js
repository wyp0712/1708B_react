import React from 'react';
import logo from './logo.svg';
import './App.css';
import './mock/index'

import { BrowserRouter } from 'react-router-dom'
import RouteView from './router/index'
import config from './router/config'

import { Provider } from 'react-redux' // 提供者
import store from './store/index'

class App extends React.Component {
  render() {
    return (
      <Provider store={store}>
        <BrowserRouter>
          <div className="App">
            <RouteView routes={config}></RouteView>
          </div>
        </BrowserRouter>
      </Provider>
    );
  }
}

export default App;
