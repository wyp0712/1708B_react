export const INIT_CART_LIST = 'init_cart_list';
export const ADD_CART_LIST = 'add_cart_item'; 
export const REMOVE_CART_LIST = 'remove_cart_item';
export const IS_SHOW_HEADER = 'is_show_header';