
const defalutState = { // 数据仓库
  cartList: [],
  list: []
}

export const reducerName = (state = defalutState, action) => {
  // 拷贝数据， 改变数据， 返回数据
  if (action.type === 'init_cart_list') {
    console.log(action, 'action')
    const newState = JSON.parse(JSON.stringify(state))
    newState.list = action.data
    return  newState
  }
  return state;
}