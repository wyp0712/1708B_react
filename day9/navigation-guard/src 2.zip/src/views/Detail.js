import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class Detail extends Component {
  static propTypes = {

  }
  render() {
    return (
      <div>
        详情
      </div>
    )
  }
}
