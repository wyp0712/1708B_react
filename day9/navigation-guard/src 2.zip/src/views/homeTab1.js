import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class homeTab1 extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
         tab1
      </div>
    )
  }
}
