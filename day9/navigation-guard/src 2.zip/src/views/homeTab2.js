import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class homeTab2 extends Component {
  static propTypes = {
  }

  render() {
    return (
      <div>
        tab2
      </div>
    )
  }
}
