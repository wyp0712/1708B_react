import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class componentName extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
        test
      </div>
    )
  }
}
