import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class Login extends Component {
  static propTypes = {

  }

  constructor(props) {
    super(props)
  }

  render() {
    // console.log(this.props, 'props----props')
    return (
      <div>
        login
      </div>
    )
  }

  componentDidMount() {
    // console.log('12')
    // console.log(this.props)
  }
}
