import React, { Component } from 'react'
// import PropTypes from 'prop-types'

export default class Cart extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
        cart
      </div>
    )
  }
}
