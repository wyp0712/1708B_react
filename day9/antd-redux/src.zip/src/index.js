import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import WrappedDemo from './App';

ReactDOM.render(<WrappedDemo />, document.getElementById('root'));

