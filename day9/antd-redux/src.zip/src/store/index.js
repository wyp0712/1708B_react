import { createStore } from 'redux'
import reducer from './reducer' // 函数

const store = createStore(reducer)


export default store