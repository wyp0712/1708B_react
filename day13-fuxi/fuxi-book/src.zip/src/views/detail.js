import React, { Component } from 'react'
import axios from 'axios'
import '../mock/index'
import { connect } from 'react-redux'

const BackBox = (props) => {
  return <div className="icon" onClick={ () => { props.history.go(-1) } }>back</div>
}

class DetailCom extends Component {
  render() {
    const { addBookStore,detailData} = this.props
    return (
      <div className="detail-page">
        <BackBox {...this.props} />
        {
          detailData.map((item) => {
            return <ul key={item.id}>
              <li>
                <img src={item.img} alt={item.name}/>
                {item.name}
                <button onClick={() => addBookStore(item)} className={ item.isCheck ? 'show' :'hide' } > { item.isCheck ? '已加入' :'加入书架' } </button>
              </li>
            </ul>
          })
        }
      </div>
    )
  }

  componentDidMount() {
    // 获取参数id 并且把id传递给dispatch中的函数
    const id = this.props.match.params.id;
    const { getDetail } = this.props;
    getDetail(id)
  }
}

const mapStateToProps = (state) => {
  return {
    detailData: state.detailData
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
     addBookStore(item) {
      console.log(item, 'item')
      let flag = true
      const action = {
        type: 'add_detail',
        flag
      }
      dispatch(action)
     },
     getDetail(id) {
       console.log(this, 'this')
      axios.get('/api/detail', {
        params: {
          id: id
        }
      }).then(res => {
        console.log(res.data, 'res')
        // this.setState({
        //   detailData: res.data
        // })
        const detailData = res.data
        const action = {
          type: 'detail_data',
          detailData
        }
        dispatch(action)
      })
     }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(DetailCom)
